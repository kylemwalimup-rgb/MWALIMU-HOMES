import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2, Home } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import DashboardLayout from "@/components/DashboardLayout";
import { formatKES } from "@shared/currency";

export default function Units() {
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingUnit, setEditingUnit] = useState<any>(null);
  const [selectedPropertyId, setSelectedPropertyId] = useState<string>("");
  
  const { data: properties, isLoading: propertiesLoading } = trpc.properties.list.useQuery();
  const { data: units, isLoading: unitsLoading } = trpc.units.list.useQuery();
  const utils = trpc.useUtils();
  
  const createMutation = trpc.units.create.useMutation({
    onSuccess: () => {
      utils.units.list.invalidate();
      setIsCreateOpen(false);
      toast.success("Unit created successfully");
    },
    onError: (error) => {
      toast.error("Failed to create unit: " + error.message);
    },
  });
  
  const updateMutation = trpc.units.update.useMutation({
    onSuccess: () => {
      utils.units.list.invalidate();
      setIsEditOpen(false);
      setEditingUnit(null);
      toast.success("Unit updated successfully");
    },
    onError: (error) => {
      toast.error("Failed to update unit: " + error.message);
    },
  });
  
  const deleteMutation = trpc.units.delete.useMutation({
    onSuccess: () => {
      utils.units.list.invalidate();
      toast.success("Unit deleted successfully");
    },
    onError: (error) => {
      toast.error("Failed to delete unit: " + error.message);
    },
  });

  const handleCreate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    createMutation.mutate({
      propertyId: parseInt(formData.get("propertyId") as string),
      unitNumber: formData.get("unitNumber") as string,
      unitType: formData.get("unitType") as any,
      baseRent: formData.get("baseRent") as string,
      serviceCharge: formData.get("serviceCharge") as string || "0",
    });
  };

  const handleUpdate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    updateMutation.mutate({
      id: editingUnit.id,
      unitNumber: formData.get("unitNumber") as string,
      unitType: formData.get("unitType") as any,
      baseRent: formData.get("baseRent") as string,
      serviceCharge: formData.get("serviceCharge") as string || "0",
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this unit?")) {
      deleteMutation.mutate({ id });
    }
  };

  const handleEdit = (unit: any) => {
    setEditingUnit(unit);
    setIsEditOpen(true);
  };

  // Filter units by selected property
  const filteredUnits = selectedPropertyId 
    ? units?.filter(u => u.propertyId === parseInt(selectedPropertyId))
    : units;

  const selectedProperty = properties?.find(p => p.id === parseInt(selectedPropertyId));

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-semibold tracking-tight">Units</h1>
            <p className="text-muted-foreground mt-1">
              {selectedProperty ? `${selectedProperty.name} - Units` : "Select a property to view units"}
            </p>
          </div>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2" disabled={!selectedPropertyId}>
                <Plus className="h-4 w-4" />
                Add Unit
              </Button>
            </DialogTrigger>
            <DialogContent>
              <form onSubmit={handleCreate}>
                <input type="hidden" name="propertyId" value={selectedPropertyId} />
                <DialogHeader>
                  <DialogTitle>Create New Unit</DialogTitle>
                  <DialogDescription>Add a new unit to the property</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="unitNumber">Unit Name/ID</Label>
                    <Input 
                      id="unitNumber" 
                      name="unitNumber" 
                      placeholder="e.g., Unit 101, Apt A" 
                      required 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="unitType">Unit Type</Label>
                    <Select name="unitType" defaultValue="1BR">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="bedsitter">Bedsitter</SelectItem>
                        <SelectItem value="single room">Single Room</SelectItem>
                        <SelectItem value="double room">Double Room</SelectItem>
                        <SelectItem value="1BR">1 Bedroom</SelectItem>
                        <SelectItem value="2BR">2 Bedroom</SelectItem>
                        <SelectItem value="shop">Shop</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="baseRent">Rent Amount (KSh)</Label>
                    <Input 
                      id="baseRent" 
                      name="baseRent" 
                      type="number" 
                      placeholder="e.g., 15000" 
                      required 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="serviceCharge">Service Charge (KSh)</Label>
                    <Input 
                      id="serviceCharge" 
                      name="serviceCharge" 
                      type="number" 
                      placeholder="e.g., 2000" 
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit" disabled={createMutation.isPending}>
                    {createMutation.isPending ? "Creating..." : "Create Unit"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Property Filter */}
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Filter by Property</CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={selectedPropertyId} onValueChange={setSelectedPropertyId}>
              <SelectTrigger>
                <SelectValue placeholder="Select a property" />
              </SelectTrigger>
              <SelectContent>
                {properties?.map(property => (
                  <SelectItem key={property.id} value={property.id.toString()}>
                    {property.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {/* Units Table */}
        <Card>
          <CardHeader>
            <CardTitle>Units</CardTitle>
            <CardDescription>
              {selectedProperty ? `All units in ${selectedProperty.name}` : "Select a property to view units"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {unitsLoading ? (
              <div className="text-center py-8">Loading units...</div>
            ) : filteredUnits && filteredUnits.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Unit Name/ID</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Rent</TableHead>
                      <TableHead>Service Charge</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUnits.map(unit => (
                      <TableRow key={unit.id}>
                        <TableCell className="font-medium">{unit.unitNumber}</TableCell>
                        <TableCell>{unit.unitType}</TableCell>
                        <TableCell>{formatKES(parseFloat(unit.baseRent))}</TableCell>
                        <TableCell>{formatKES(parseFloat(unit.serviceCharge))}</TableCell>
                        <TableCell>
                          <Badge 
                            variant={unit.status === 'occupied' ? 'default' : 'secondary'}
                            className={unit.status === 'occupied' ? 'bg-green-600' : 'bg-red-600'}
                          >
                            {unit.status === 'occupied' ? '🟢 Occupied' : '🔴 Vacant'}
                          </Badge>
                        </TableCell>
                        <TableCell className="space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(unit)}
                            className="gap-2"
                          >
                            <Pencil className="h-4 w-4" />
                            Edit
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleDelete(unit.id)}
                            className="gap-2"
                          >
                            <Trash2 className="h-4 w-4" />
                            Delete
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-8">
                <Home className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">
                  {selectedProperty ? "No units in this property yet." : "Select a property to view units."}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Edit Dialog */}
        <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
          <DialogContent>
            <form onSubmit={handleUpdate}>
              <DialogHeader>
                <DialogTitle>Edit Unit</DialogTitle>
                <DialogDescription>Update unit details</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-unitNumber">Unit Name/ID</Label>
                  <Input 
                    id="edit-unitNumber" 
                    name="unitNumber" 
                    defaultValue={editingUnit?.unitNumber || ""} 
                    required 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-unitType">Unit Type</Label>
                  <Select name="unitType" defaultValue={editingUnit?.unitType || "1BR"}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bedsitter">Bedsitter</SelectItem>
                      <SelectItem value="single room">Single Room</SelectItem>
                      <SelectItem value="double room">Double Room</SelectItem>
                      <SelectItem value="1BR">1 Bedroom</SelectItem>
                      <SelectItem value="2BR">2 Bedroom</SelectItem>
                      <SelectItem value="shop">Shop</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-baseRent">Rent Amount (KSh)</Label>
                  <Input 
                    id="edit-baseRent" 
                    name="baseRent" 
                    type="number" 
                    defaultValue={editingUnit?.baseRent || ""} 
                    required 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-serviceCharge">Service Charge (KSh)</Label>
                  <Input 
                    id="edit-serviceCharge" 
                    name="serviceCharge" 
                    type="number" 
                    defaultValue={editingUnit?.serviceCharge || ""} 
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" disabled={updateMutation.isPending}>
                  {updateMutation.isPending ? "Updating..." : "Update Unit"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
