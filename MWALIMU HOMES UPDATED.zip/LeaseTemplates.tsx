import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import type { ReactNode } from "react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Plus, Download, Edit2, Trash2, FileText, Info } from "lucide-react";
import { toast } from "sonner";
import DashboardLayout from "@/components/DashboardLayout";
import { jsPDF } from "jspdf";

interface LeaseTemplate {
  id: number;
  name: string;
  content: string;
  isDefault: boolean;
}

const DEFAULT_TEMPLATE = `MWALIMU HOMES - TENANT LEASE AGREEMENT

This Lease Agreement ("Agreement") is entered into on {{LEASE_DATE}} between:

LANDLORD:
MWALIMU HOMES
Property Manager

TENANT:
Name: {{TENANT_NAME}}
National ID: {{TENANT_ID}}
Primary Phone: {{TENANT_PHONE}}
Secondary Phone: {{TENANT_SECONDARY_PHONE}}

PROPERTY:
Property: {{PROPERTY_NAME}}
Unit: {{UNIT_NUMBER}} ({{UNIT_TYPE}})
Address: {{UNIT_ADDRESS}}

LEASE TERMS:
1. Monthly Rent: KSh {{MONTHLY_RENT}}
2. Service Charge: KSh {{SERVICE_CHARGE}}
3. Security Deposit: KSh {{SECURITY_DEPOSIT}}
4. Lease Start Date: {{LEASE_START_DATE}}
5. Lease Duration: {{LEASE_DURATION}} months
6. Payment Due Date: 1st of each month

PAYMENT DETAILS:
Payment Mode: Equity Paybill
Paybill Number: 247247
Payment Instructions:
- Send payment via M-Pesa to Paybill 247247
- Use your Unit Number ({{UNIT_NUMBER}}) as the account reference
- Payments must be received by the 1st of each month
- Keep the M-Pesa receipt for your records

TENANT OBLIGATIONS:
- Pay rent on or before the 1st of each month
- Maintain the unit in good condition
- Report maintenance issues promptly
- Comply with house rules and regulations
- Provide 30 days notice before vacating

LANDLORD OBLIGATIONS:
- Maintain the property in habitable condition
- Respond to maintenance requests within 48 hours
- Respect tenant's privacy and quiet enjoyment
- Return security deposit within 30 days of move-out

CONTACT INFORMATION:
Mwalimu Homes Management
Phone: 0713577499

SIGNATURES:

Tenant: _________________________ Date: _________

Landlord: _______________________ Date: _________

Witness: ________________________ Date: _________`;

export default function LeaseTemplates() {
  const [templates, setTemplates] = useState<LeaseTemplate[]>([
    {
      id: 1,
      name: "Standard Lease Agreement",
      content: DEFAULT_TEMPLATE,
      isDefault: true,
    },
  ]);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<LeaseTemplate | null>(null);
  const [templateName, setTemplateName] = useState("");
  const [templateContent, setTemplateContent] = useState("");

  const handleCreateTemplate = () => {
    if (!templateName.trim() || !templateContent.trim()) {
      toast.error("Please fill in all fields");
      return;
    }

    const newTemplate: LeaseTemplate = {
      id: Math.max(...templates.map((t) => t.id), 0) + 1,
      name: templateName,
      content: templateContent,
      isDefault: false,
    };

    setTemplates([...templates, newTemplate]);
    setTemplateName("");
    setTemplateContent("");
    setIsCreateOpen(false);
    toast.success("Template created successfully");
  };

  const handleUpdateTemplate = () => {
    if (!editingTemplate || !templateName.trim() || !templateContent.trim()) {
      toast.error("Please fill in all fields");
      return;
    }

    setTemplates(
      templates.map((t) =>
        t.id === editingTemplate.id
          ? { ...t, name: templateName, content: templateContent }
          : t
      )
    );
    setEditingTemplate(null);
    setTemplateName("");
    setTemplateContent("");
    toast.success("Template updated successfully");
  };

  const handleDeleteTemplate = (id: number) => {
    if (confirm("Are you sure you want to delete this template?")) {
      setTemplates(templates.filter((t) => t.id !== id));
      toast.success("Template deleted successfully");
    }
  };

  const handleSetDefault = (id: number) => {
    setTemplates(
      templates.map((t) => ({
        ...t,
        isDefault: t.id === id,
      }))
    );
    toast.success("Default template updated");
  };

  const downloadTemplatePDF = (template: LeaseTemplate) => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 10;
    const maxWidth = pageWidth - 2 * margin;

    let yPosition = margin;
    const lineHeight = 5;
    const fontSize = 10;

    doc.setFontSize(fontSize);

    // Split content into lines
    const lines = doc.splitTextToSize(template.content, maxWidth);

    lines.forEach((line: string) => {
      if (yPosition > pageHeight - margin) {
        doc.addPage();
        yPosition = margin;
      }
      doc.text(line, margin, yPosition);
      yPosition += lineHeight;
    });

    doc.save(`${template.name.replace(/\s+/g, "_")}.pdf`);
    toast.success("Template downloaded as PDF");
  };

  const openEditDialog = (template: LeaseTemplate) => {
    setEditingTemplate(template);
    setTemplateName(template.name);
    setTemplateContent(template.content);
  };

  const closeEditDialog = () => {
    setEditingTemplate(null);
    setTemplateName("");
    setTemplateContent("");
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-semibold tracking-tight">Lease Agreement Templates</h1>
            <p className="text-muted-foreground mt-1">Create and manage editable lease agreement templates</p>
          </div>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                New Template
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create New Template</DialogTitle>
                <DialogDescription>Create a new lease agreement template with editable variables</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="template-name">Template Name</Label>
                  <Input
                    id="template-name"
                    placeholder="e.g., Standard Lease Agreement"
                    value={templateName}
                    onChange={(e) => setTemplateName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="template-content">Template Content</Label>
                  <Alert>
                    <Info className="h-4 w-4" />
                    <AlertDescription>
                      Use variables like {'{TENANT_NAME}'}, {'{MONTHLY_RENT}'}, {'{LEASE_DATE}'} to auto-populate tenant and property data
                    </AlertDescription>
                  </Alert>
                  <Textarea
                    id="template-content"
                    placeholder="Enter template content..."
                    value={templateContent}
                    onChange={(e) => setTemplateContent(e.target.value)}
                    className="min-h-96 font-mono text-sm"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateTemplate}>Create Template</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-4">
          {templates.map((template) => (
            <Card key={template.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <FileText className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {template.name}
                        {template.isDefault && <Badge>Default</Badge>}
                      </CardTitle>
                      <CardDescription className="mt-1">
                        {template.content.split("\n").length} lines • {template.content.length} characters
                      </CardDescription>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => downloadTemplatePDF(template)}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => openEditDialog(template)}
                    >
                      <Edit2 className="h-4 w-4 mr-2" />
                      Edit
                    </Button>
                    {!template.isDefault && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleSetDefault(template.id)}
                      >
                        Set Default
                      </Button>
                    )}
                    {!template.isDefault && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteTemplate(template.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="bg-muted p-4 rounded text-sm max-h-32 overflow-y-auto font-mono whitespace-pre-wrap">
                  {template.content.substring(0, 300)}...
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {editingTemplate && (
          <Dialog open={!!editingTemplate} onOpenChange={closeEditDialog}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Edit Template</DialogTitle>
                <DialogDescription>Update the lease agreement template</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-template-name">Template Name</Label>
                  <Input
                    id="edit-template-name"
                    value={templateName}
                    onChange={(e) => setTemplateName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-template-content">Template Content</Label>
                  <Textarea
                    id="edit-template-content"
                    value={templateContent}
                    onChange={(e) => setTemplateContent(e.target.value)}
                    className="min-h-96 font-mono text-sm"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={closeEditDialog}>
                  Cancel
                </Button>
                <Button onClick={handleUpdateTemplate}>Save Changes</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </DashboardLayout>
  );
}
