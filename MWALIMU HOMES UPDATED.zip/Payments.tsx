import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Plus, Upload, AlertCircle, CheckCircle, Clock } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import DashboardLayout from "@/components/DashboardLayout";
import { formatKES } from "@shared/currency";
import { trpc } from "@/lib/trpc";
import { parseBulkMpesaMessages } from "@shared/mpesa-parser";

export default function Payments() {
  const [isRecordOpen, setIsRecordOpen] = useState(false);
  const [isBulkOpen, setIsBulkOpen] = useState(false);
  const [bulkMessages, setBulkMessages] = useState("");
  const [selectedProperty, setSelectedProperty] = useState<string>("");
  const [selectedTenant, setSelectedTenant] = useState<string>("");
  
  const { data: payments, isLoading: paymentsLoading } = trpc.payments.list.useQuery();
  const { data: properties } = trpc.properties.list.useQuery();
  const { data: tenants } = trpc.tenants.list.useQuery();
  const { data: units } = trpc.units.list.useQuery();
  const { data: unassignedPayments } = trpc.payments.getUnassignedPayments.useQuery();
  const utils = trpc.useUtils();
  
  const createPaymentMutation = trpc.payments.create.useMutation({
    onSuccess: () => {
      utils.payments.list.invalidate();
      utils.invoices.list.invalidate();
      setIsRecordOpen(false);
      toast.success("Payment recorded successfully");
    },
    onError: (error) => {
      toast.error("Failed to record payment: " + error.message);
    },
  });

  const bulkUploadMutation = trpc.payments.bulkUploadMpesa.useMutation({
    onSuccess: (result) => {
      utils.payments.list.invalidate();
      utils.payments.getUnassignedPayments.invalidate();
      setIsBulkOpen(false);
      setBulkMessages("");
      
      const matched = result.filter((r: any) => r.matched).length;
      const unmatched = result.length - matched;
      
      toast.success(`Imported ${result.length} payments (${matched} matched, ${unmatched} unmatched)`);
    },
    onError: (error) => {
      toast.error("Failed to import payments: " + error.message);
    },
  });

  const handleRecordPayment = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const tenantId = parseInt(formData.get("tenantId") as string);
    const tenant = tenants?.find(t => t.id === tenantId);
    
    if (!tenant) {
      toast.error("Tenant not found");
      return;
    }

    createPaymentMutation.mutate({
      tenantId,
      amount: formData.get("amount") as string,
      paymentMethod: formData.get("paymentMethod") as any,
      paymentDate: new Date(formData.get("paymentDate") as string),
      transactionReference: formData.get("transactionReference") as string || undefined,
      notes: formData.get("notes") as string || undefined,
    });
  };

  const handleBulkUpload = async () => {
    if (!bulkMessages.trim()) {
      toast.error("Please paste M-Pesa messages");
      return;
    }

    try {
      const parsedMessages = parseBulkMpesaMessages(bulkMessages);
      
      if (parsedMessages.length === 0) {
        toast.error("No valid M-Pesa messages found");
        return;
      }

      bulkUploadMutation.mutate({
        messages: parsedMessages,
      });
    } catch (error) {
      toast.error("Failed to parse M-Pesa messages");
    }
  };

  const filteredTenants = selectedProperty
    ? tenants?.filter(t => t.propertyId === parseInt(selectedProperty))
    : tenants;

  const selectedTenantData = tenants?.find(t => t.id === parseInt(selectedTenant));
  const expectedRent = selectedTenantData?.monthlyRent || "0.00";

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Payments</h1>
            <p className="text-sm text-muted-foreground mt-1">Manage rent payments and M-Pesa transactions</p>
          </div>
          <div className="flex gap-2">
            {unassignedPayments && unassignedPayments.length > 0 && (
              <div className="flex items-center gap-2 px-3 py-2 bg-red-50 border border-red-200 rounded-lg">
                <AlertCircle className="w-4 h-4 text-red-600" />
                <span className="text-sm font-medium text-red-600">{unassignedPayments.length} unassigned</span>
              </div>
            )}
          </div>
        </div>

        {/* Two-column layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Section 1: Record Payment (Manual) */}
          <Card>
            <CardHeader>
              <CardTitle>Record Payment</CardTitle>
              <CardDescription>Manually record a rent payment</CardDescription>
            </CardHeader>
            <CardContent>
              <Dialog open={isRecordOpen} onOpenChange={setIsRecordOpen}>
                <DialogTrigger asChild>
                  <Button className="w-full mb-4" size="lg">
                    <Plus className="w-4 h-4 mr-2" />
                    Record New Payment
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Record Payment</DialogTitle>
                    <DialogDescription>Enter payment details for a tenant</DialogDescription>
                  </DialogHeader>
                  
                  <form onSubmit={handleRecordPayment} className="space-y-4">
                    {/* Select Property */}
                    <div className="space-y-2">
                      <Label htmlFor="property">Select Property</Label>
                      <Select value={selectedProperty} onValueChange={setSelectedProperty}>
                        <SelectTrigger>
                          <SelectValue placeholder="Choose property..." />
                        </SelectTrigger>
                        <SelectContent>
                          {properties?.map(prop => (
                            <SelectItem key={prop.id} value={prop.id.toString()}>
                              {prop.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Select Tenant */}
                    <div className="space-y-2">
                      <Label htmlFor="tenantId">Select Tenant</Label>
                      <Select value={selectedTenant} onValueChange={setSelectedTenant}>
                        <SelectTrigger name="tenantId">
                          <SelectValue placeholder="Choose tenant..." />
                        </SelectTrigger>
                        <SelectContent>
                          {filteredTenants?.map(tenant => (
                            <SelectItem key={tenant.id} value={tenant.id.toString()}>
                              {tenant.firstName} {tenant.lastName} - Unit {tenant.unitId}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Expected Monthly Rent (Auto-fill) */}
                    <div className="space-y-2">
                      <Label>Expected Monthly Rent</Label>
                      <div className="px-3 py-2 bg-muted rounded-md border">
                        <p className="text-sm font-medium">{formatKES(expectedRent)}</p>
                      </div>
                    </div>

                    {/* Paid Amount */}
                    <div className="space-y-2">
                      <Label htmlFor="amount">Paid Amount</Label>
                      <Input
                        id="amount"
                        name="amount"
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        required
                      />
                    </div>

                    {/* Payment Type */}
                    <div className="space-y-2">
                      <Label htmlFor="paymentMethod">Payment Type</Label>
                      <Select name="paymentMethod" defaultValue="mpesa">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="mpesa">M-Pesa</SelectItem>
                          <SelectItem value="cash">Cash</SelectItem>
                          <SelectItem value="bank">Bank Transfer</SelectItem>
                          <SelectItem value="cheque">Cheque</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Transaction Code */}
                    <div className="space-y-2">
                      <Label htmlFor="transactionReference">Transaction Code</Label>
                      <Input
                        id="transactionReference"
                        name="transactionReference"
                        placeholder="e.g., TLO8G1XDCL"
                      />
                    </div>

                    {/* Date Paid */}
                    <div className="space-y-2">
                      <Label htmlFor="paymentDate">Date Paid</Label>
                      <Input
                        id="paymentDate"
                        name="paymentDate"
                        type="date"
                        required
                      />
                    </div>

                    {/* Notes */}
                    <div className="space-y-2">
                      <Label htmlFor="notes">Notes</Label>
                      <Textarea
                        id="notes"
                        name="notes"
                        placeholder="Additional notes (optional)"
                        rows={3}
                      />
                    </div>

                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={() => setIsRecordOpen(false)}>
                        Cancel
                      </Button>
                      <Button type="submit" disabled={createPaymentMutation.isPending}>
                        {createPaymentMutation.isPending ? "Recording..." : "Confirm Payment"}
                      </Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>

              {/* Recent Manual Payments */}
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-foreground">Recent Payments</h3>
                {payments && payments.length > 0 ? (
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {payments.slice(0, 5).map(payment => (
                      <div key={payment.id} className="flex items-center justify-between p-2 border rounded-lg">
                        <div>
                          <p className="text-sm font-medium">{formatKES(payment.amount)}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(payment.paymentDate).toLocaleDateString()}
                          </p>
                        </div>
                        <Badge variant={payment.paymentMethod === 'mpesa' ? 'default' : 'secondary'}>
                          {payment.paymentMethod}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">No payments recorded yet</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Section 2: Bulk Upload */}
          <Card>
            <CardHeader>
              <CardTitle>Bulk Payment Upload</CardTitle>
              <CardDescription>Import M-Pesa messages</CardDescription>
            </CardHeader>
            <CardContent>
              <Dialog open={isBulkOpen} onOpenChange={setIsBulkOpen}>
                <DialogTrigger asChild>
                  <Button className="w-full mb-4" size="lg" variant="outline">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Bulk Payment
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Upload Bulk Payments</DialogTitle>
                    <DialogDescription>
                      Paste M-Pesa confirmation messages (one per line)
                    </DialogDescription>
                  </DialogHeader>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="bulkMessages">M-Pesa Messages</Label>
                      <Textarea
                        id="bulkMessages"
                        value={bulkMessages}
                        onChange={(e) => setBulkMessages(e.target.value)}
                        placeholder="Paste M-Pesa messages here (one per line)&#10;Example: (Confirmed KES. 2,500.00 to BENJAMINMWALIMUKYONGO A/C Ref.Number 577499 Via MPESA Ref TLO8G1XDCL by SHEDRACK KIOKO MUTUA Phone 254748908204 on 24-12-2025 at 12:55.Thank you.)"
                        rows={8}
                        className="font-mono text-xs"
                      />
                    </div>

                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                      <p className="text-xs text-blue-700">
                        <strong>Format:</strong> Each line should be a complete M-Pesa confirmation message. The system will automatically extract amount, payer name, phone, and reference.
                      </p>
                    </div>

                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={() => setIsBulkOpen(false)}>
                        Cancel
                      </Button>
                      <Button 
                        onClick={handleBulkUpload} 
                        disabled={bulkUploadMutation.isPending || !bulkMessages.trim()}
                      >
                        {bulkUploadMutation.isPending ? "Processing..." : "Update Payments"}
                      </Button>
                    </DialogFooter>
                  </div>
                </DialogContent>
              </Dialog>

              {/* Unassigned Payments */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-foreground">Unassigned Payments</h3>
                  {unassignedPayments && unassignedPayments.length > 0 && (
                    <Badge variant="destructive">{unassignedPayments.length}</Badge>
                  )}
                </div>

                {unassignedPayments && unassignedPayments.length > 0 ? (
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {unassignedPayments.map(payment => (
                      <div key={payment.id} className="p-3 border border-red-200 bg-red-50 rounded-lg">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <p className="text-sm font-medium">{payment.payerName}</p>
                            <p className="text-xs text-muted-foreground">
                              {formatKES(payment.amount)} • {payment.phoneNumber}
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">
                              Ref: {payment.referenceCode}
                            </p>
                          </div>
                          <AlertCircle className="w-4 h-4 text-red-600 mt-1 flex-shrink-0" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <p className="text-sm text-green-700">All payments assigned</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Payment History Table */}
        <Card>
          <CardHeader>
            <CardTitle>Payment History</CardTitle>
            <CardDescription>All recorded payments</CardDescription>
          </CardHeader>
          <CardContent>
            {paymentsLoading ? (
              <p className="text-sm text-muted-foreground">Loading payments...</p>
            ) : payments && payments.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Method</TableHead>
                      <TableHead>Reference</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {payments.map(payment => (
                      <TableRow key={payment.id}>
                        <TableCell className="text-sm">
                          {new Date(payment.paymentDate).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="text-sm font-medium">
                          {formatKES(payment.amount)}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="capitalize">
                            {payment.paymentMethod}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {payment.transactionReference || '-'}
                        </TableCell>
                        <TableCell>
                          <Badge className="bg-green-100 text-green-800">Recorded</Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">No payments recorded yet</p>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
