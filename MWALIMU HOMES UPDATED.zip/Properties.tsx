import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Building2, Plus, Pencil, Trash2, Home } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import DashboardLayout from "@/components/DashboardLayout";
import { useLocation } from "wouter";
import { formatKES } from "@shared/currency";
import { trpc } from "@/lib/trpc";

export default function Properties() {
  const [, setLocation] = useLocation();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingProperty, setEditingProperty] = useState<any>(null);
  
  const { data: properties, isLoading } = trpc.properties.list.useQuery();
  const { data: units } = trpc.units.list.useQuery();
  const utils = trpc.useUtils();
  
  const createMutation = trpc.properties.create.useMutation({
    onSuccess: () => {
      utils.properties.list.invalidate();
      setIsCreateOpen(false);
      toast.success("Property created successfully");
    },
    onError: (error) => {
      toast.error("Failed to create property: " + error.message);
    },
  });
  
  const updateMutation = trpc.properties.update.useMutation({
    onSuccess: () => {
      utils.properties.list.invalidate();
      setIsEditOpen(false);
      setEditingProperty(null);
      toast.success("Property updated successfully");
    },
    onError: (error) => {
      toast.error("Failed to update property: " + error.message);
    },
  });
  
  const deleteMutation = trpc.properties.delete.useMutation({
    onSuccess: () => {
      utils.properties.list.invalidate();
      toast.success("Property deleted successfully");
    },
    onError: (error) => {
      toast.error("Failed to delete property: " + error.message);
    },
  });

  const handleCreate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    createMutation.mutate({
      name: formData.get("name") as string,
      address: formData.get("address") as string,
      description: formData.get("description") as string || undefined,
    });
  };

  const handleUpdate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    updateMutation.mutate({
      id: editingProperty.id,
      name: formData.get("name") as string,
      address: formData.get("address") as string,
      description: formData.get("description") as string || undefined,
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this property? This will also delete all units and tenants in this property.")) {
      deleteMutation.mutate({ id });
    }
  };

  const handleEdit = (property: any) => {
    setEditingProperty(property);
    setIsEditOpen(true);
  };

  // Calculate summary statistics
  const totalProperties = properties?.length || 0;
  const totalUnits = units?.length || 0;
  const occupiedUnits = units?.filter(u => u.status === 'occupied').length || 0;
  const percentageOccupied = totalUnits > 0 ? ((occupiedUnits / totalUnits) * 100).toFixed(1) : 0;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-semibold tracking-tight">Properties</h1>
            <p className="text-muted-foreground mt-1">Manage your rental properties</p>
          </div>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Add Property
              </Button>
            </DialogTrigger>
            <DialogContent>
              <form onSubmit={handleCreate}>
                <DialogHeader>
                  <DialogTitle>Create New Property</DialogTitle>
                  <DialogDescription>Add a new property to your portfolio</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Property Name</Label>
                    <Input id="name" name="name" placeholder="e.g., Westlands Apartments" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="address">City/Location</Label>
                    <Input id="address" name="address" placeholder="e.g., Nairobi" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Description (Optional)</Label>
                    <Textarea id="description" name="description" placeholder="e.g., Modern apartment complex with 20 units" />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit" disabled={createMutation.isPending}>
                    {createMutation.isPending ? "Creating..." : "Create Property"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Summary Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Properties</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{totalProperties}</div>
              <p className="text-xs text-muted-foreground mt-1">{totalUnits} total units</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Percentage Occupied</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">{percentageOccupied}%</div>
              <p className="text-xs text-muted-foreground mt-1">{occupiedUnits} of {totalUnits} units</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Vacant Units</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-red-600">{totalUnits - occupiedUnits}</div>
              <p className="text-xs text-muted-foreground mt-1">Awaiting tenants</p>
            </CardContent>
          </Card>
        </div>

        {/* Properties Grid with Cards */}
        <div>
          <h2 className="text-xl font-semibold mb-4">Your Properties</h2>
          {isLoading ? (
            <div className="text-center py-12">Loading properties...</div>
          ) : properties && properties.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {properties.map(property => {
                const propertyUnits = units?.filter(u => u.propertyId === property.id) || [];
                const propertyOccupied = propertyUnits.filter(u => u.status === 'occupied').length;
                const propertyVacant = propertyUnits.length - propertyOccupied;
                
                return (
                  <Card key={property.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-lg">{property.name}</CardTitle>
                          <CardDescription className="mt-1">{property.address}</CardDescription>
                        </div>
                        <Building2 className="h-8 w-8 text-blue-600 opacity-20" />
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      {/* Property Stats */}
                      <div className="grid grid-cols-3 gap-2 text-center">
                        <div className="bg-blue-50 rounded-lg p-3">
                          <div className="text-xl font-bold text-blue-600">{propertyUnits.length}</div>
                          <div className="text-xs text-muted-foreground">Units</div>
                        </div>
                        <div className="bg-green-50 rounded-lg p-3">
                          <div className="text-xl font-bold text-green-600">{propertyOccupied}</div>
                          <div className="text-xs text-muted-foreground">Occupied</div>
                        </div>
                        <div className="bg-red-50 rounded-lg p-3">
                          <div className="text-xl font-bold text-red-600">{propertyVacant}</div>
                          <div className="text-xs text-muted-foreground">Vacant</div>
                        </div>
                      </div>

                      {/* Description */}
                      {property.description && (
                        <p className="text-sm text-muted-foreground">{property.description}</p>
                      )}

                      {/* Action Buttons */}
                      <div className="flex gap-2 pt-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEdit(property)}
                          className="flex-1 gap-2"
                        >
                          <Pencil className="h-4 w-4" />
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDelete(property.id)}
                          className="flex-1 gap-2"
                        >
                          <Trash2 className="h-4 w-4" />
                          Delete
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Building2 className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No properties yet. Create one to get started.</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Edit Dialog */}
        <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
          <DialogContent>
            <form onSubmit={handleUpdate}>
              <DialogHeader>
                <DialogTitle>Edit Property</DialogTitle>
                <DialogDescription>Update property details</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">Property Name</Label>
                  <Input 
                    id="edit-name" 
                    name="name" 
                    defaultValue={editingProperty?.name || ""} 
                    required 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-address">City/Location</Label>
                  <Input 
                    id="edit-address" 
                    name="address" 
                    defaultValue={editingProperty?.address || ""} 
                    required 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-description">Description (Optional)</Label>
                  <Textarea 
                    id="edit-description" 
                    name="description" 
                    defaultValue={editingProperty?.description || ""} 
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" disabled={updateMutation.isPending}>
                  {updateMutation.isPending ? "Updating..." : "Update Property"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
