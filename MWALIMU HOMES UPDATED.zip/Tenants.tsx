import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Pencil, Trash2, Download, FileText } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { formatCurrency } from "@/lib/currency";
import { generateTenantListPDF } from "@/lib/pdf-generator";

export default function Tenants() {
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingTenant, setEditingTenant] = useState<any>(null);
  const [selectedPropertyId, setSelectedPropertyId] = useState<string>("");
  
  const { data: properties } = trpc.properties.list.useQuery();
  const { data: units } = trpc.units.list.useQuery();
  const { data: allTenants, isLoading } = trpc.tenants.list.useQuery();
  const { data: tenantsByProperty } = trpc.tenants.listByProperty.useQuery(
    { propertyId: parseInt(selectedPropertyId) },
    { enabled: !!selectedPropertyId }
  );
  
  const utils = trpc.useUtils();
  
  const createMutation = trpc.tenants.create.useMutation({
    onSuccess: () => {
      utils.tenants.list.invalidate();
      if (selectedPropertyId) {
        utils.tenants.listByProperty.invalidate({ propertyId: parseInt(selectedPropertyId) });
      }
      setIsCreateOpen(false);
      toast.success("Tenant created successfully");
    },
    onError: (error) => {
      toast.error("Failed to create tenant: " + error.message);
    },
  });
  
  const updateMutation = trpc.tenants.update.useMutation({
    onSuccess: () => {
      utils.tenants.list.invalidate();
      if (selectedPropertyId) {
        utils.tenants.listByProperty.invalidate({ propertyId: parseInt(selectedPropertyId) });
      }
      setEditingTenant(null);
      toast.success("Tenant updated successfully");
    },
    onError: (error) => {
      toast.error("Failed to update tenant: " + error.message);
    },
  });
  
  const deleteMutation = trpc.tenants.delete.useMutation({
    onSuccess: () => {
      utils.tenants.list.invalidate();
      if (selectedPropertyId) {
        utils.tenants.listByProperty.invalidate({ propertyId: parseInt(selectedPropertyId) });
      }
      toast.success("Tenant deleted successfully");
    },
    onError: (error) => {
      toast.error("Failed to delete tenant: " + error.message);
    },
  });

  const displayTenants = selectedPropertyId ? tenantsByProperty : allTenants;
  
  const selectedProperty = properties?.find(p => p.id === parseInt(selectedPropertyId));

  const handleCreate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const propertyId = parseInt(formData.get("propertyId") as string);
    const unitId = parseInt(formData.get("unitId") as string);
    const primaryPhone = formData.get("primaryPhone") as string;
    
    if (!primaryPhone.startsWith("254")) {
      toast.error("Phone number must start with 254");
      return;
    }
    
    createMutation.mutate({
      propertyId,
      unitId,
      firstName: formData.get("firstName") as string,
      lastName: formData.get("lastName") as string,
      email: (formData.get("email") as string) || undefined,
      primaryPhone,
      secondaryPhone: (formData.get("secondaryPhone") as string) || undefined,
      nationalId: formData.get("nationalId") as string,
      identityCardFile: (formData.get("identityCardFile") as string) || undefined,
      moveInDate: (formData.get("moveInDate") as string) || undefined,
      monthlyRent: formData.get("monthlyRent") as string,
      securityDeposit: formData.get("securityDeposit") as string,
      electricityDeposit: (formData.get("electricityDeposit") as string) || "0",
      agreementFile: (formData.get("agreementFile") as string) || undefined,
    });
  };

  const handleUpdate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const primaryPhone = formData.get("primaryPhone") as string;
    
    if (primaryPhone && !primaryPhone.startsWith("254")) {
      toast.error("Phone number must start with 254");
      return;
    }
    
    updateMutation.mutate({
      id: editingTenant.id,
      propertyId: parseInt(formData.get("propertyId") as string) || undefined,
      unitId: parseInt(formData.get("unitId") as string) || undefined,
      firstName: (formData.get("firstName") as string) || undefined,
      lastName: (formData.get("lastName") as string) || undefined,
      email: (formData.get("email") as string) || undefined,
      primaryPhone: primaryPhone || undefined,
      secondaryPhone: (formData.get("secondaryPhone") as string) || undefined,
      nationalId: (formData.get("nationalId") as string) || undefined,
      identityCardFile: (formData.get("identityCardFile") as string) || undefined,
      moveInDate: (formData.get("moveInDate") as string) || undefined,
      monthlyRent: (formData.get("monthlyRent") as string) || undefined,
      securityDeposit: (formData.get("securityDeposit") as string) || undefined,
      electricityDeposit: (formData.get("electricityDeposit") as string) || undefined,
      agreementFile: (formData.get("agreementFile") as string) || undefined,
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this tenant?")) {
      deleteMutation.mutate({ id });
    }
  };

  const handleDownloadPDF = () => {
    if (!selectedProperty || !displayTenants) {
      toast.error("Please select a property first");
      return;
    }
    
    try {
      generateTenantListPDF(selectedProperty.name, displayTenants);
      toast.success("PDF downloaded successfully");
    } catch (error) {
      toast.error("Failed to generate PDF");
      console.error(error);
    }
  };

  const TenantForm = ({ tenant, onSubmit, isPending }: any) => {
    const formPropertyId = tenant?.propertyId || "";
    const formUnitId = tenant?.unitId || "";
    const availableUnits = formPropertyId ? units?.filter(u => u.propertyId === parseInt(formPropertyId)) : [];
    
    return (
      <form onSubmit={onSubmit}>
        <div className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="propertyId">Property *</Label>
              <Select defaultValue={formPropertyId.toString()} onValueChange={(value) => {}}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {properties?.map(p => (
                    <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <input type="hidden" name="propertyId" value={formPropertyId} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="unitId">Unit *</Label>
              <Select defaultValue={formUnitId.toString()} onValueChange={(value) => {}}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {availableUnits?.map(u => (
                    <SelectItem key={u.id} value={u.id.toString()}>{u.unitNumber}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <input type="hidden" name="unitId" value={formUnitId} required />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="firstName">First Name *</Label>
              <Input id="firstName" name="firstName" defaultValue={tenant?.firstName} placeholder="John" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name *</Label>
              <Input id="lastName" name="lastName" defaultValue={tenant?.lastName} placeholder="Doe" required />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="primaryPhone">Primary Phone (254...) *</Label>
            <Input id="primaryPhone" name="primaryPhone" defaultValue={tenant?.primaryPhone} placeholder="254712345678" required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="secondaryPhone">Secondary Phone (Optional)</Label>
            <Input id="secondaryPhone" name="secondaryPhone" defaultValue={tenant?.secondaryPhone} placeholder="254712345679" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="nationalId">National ID *</Label>
            <Input id="nationalId" name="nationalId" defaultValue={tenant?.nationalId} placeholder="12345678" required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email (Optional)</Label>
            <Input id="email" name="email" type="email" defaultValue={tenant?.email} placeholder="john@example.com" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="moveInDate">Move-In Date (YYYY-MM) (Optional)</Label>
            <Input id="moveInDate" name="moveInDate" defaultValue={tenant?.moveInDate} placeholder="2025-01" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="monthlyRent">Monthly Rent (KSh) *</Label>
              <Input id="monthlyRent" name="monthlyRent" type="number" step="0.01" defaultValue={tenant?.monthlyRent} placeholder="15000" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="securityDeposit">Security Deposit (KSh) *</Label>
              <Input id="securityDeposit" name="securityDeposit" type="number" step="0.01" defaultValue={tenant?.securityDeposit} placeholder="15000" required />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="electricityDeposit">Electricity Deposit (KSh) (Optional)</Label>
            <Input id="electricityDeposit" name="electricityDeposit" type="number" step="0.01" defaultValue={tenant?.electricityDeposit || "0"} placeholder="5000" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="identityCardFile">Identity Card File (Optional)</Label>
            <Input id="identityCardFile" name="identityCardFile" type="file" defaultValue={tenant?.identityCardFile} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="agreementFile">Agreement File (Optional)</Label>
            <Input id="agreementFile" name="agreementFile" type="file" defaultValue={tenant?.agreementFile} />
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" disabled={isPending}>
            {isPending ? "Saving..." : tenant ? "Update Tenant" : "Create Tenant"}
          </Button>
        </DialogFooter>
      </form>
    );
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Tenants</h1>
            <p className="text-slate-600">Manage tenant information and records</p>
          </div>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Tenant
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add New Tenant</DialogTitle>
                <DialogDescription>Enter tenant information and assign to a unit</DialogDescription>
              </DialogHeader>
              <TenantForm onSubmit={handleCreate} isPending={createMutation.isPending} />
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Filter by Property</CardTitle>
            <CardDescription>Select a property to view and manage tenants</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4 items-end">
              <div className="flex-1">
                <Label htmlFor="property-select">Property</Label>
                <Select value={selectedPropertyId} onValueChange={setSelectedPropertyId}>
                  <SelectTrigger id="property-select">
                    <SelectValue placeholder="Select a property..." />
                  </SelectTrigger>
                  <SelectContent>
                    {properties?.map(p => (
                      <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {selectedPropertyId && (
                <Button 
                  onClick={handleDownloadPDF}
                  variant="outline"
                  className="gap-2"
                >
                  <Download className="w-4 h-4" />
                  Download PDF
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Tenant List
            </CardTitle>
            <CardDescription>
              {selectedProperty ? `Tenants in ${selectedProperty.name}` : "Select a property to view tenants"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8 text-slate-500">Loading...</div>
            ) : !selectedPropertyId ? (
              <div className="text-center py-8 text-slate-500">Select a property to view tenants</div>
            ) : !displayTenants || displayTenants.length === 0 ? (
              <div className="text-center py-8 text-slate-500">No tenants found for this property</div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Unit</TableHead>
                      <TableHead>Phone</TableHead>
                      <TableHead>Monthly Rent</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {displayTenants.map((tenant: any) => {
                      const unit = units?.find(u => u.id === tenant.unitId);
                      return (
                        <TableRow key={tenant.id}>
                          <TableCell className="font-medium">{tenant.firstName} {tenant.lastName}</TableCell>
                          <TableCell>{unit?.unitNumber || "N/A"}</TableCell>
                          <TableCell>{tenant.primaryPhone}</TableCell>
                          <TableCell>{formatCurrency(parseFloat(tenant.monthlyRent))}</TableCell>
                          <TableCell className="flex gap-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => setEditingTenant(tenant)}
                                >
                                  <Pencil className="w-4 h-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-2xl">
                                <DialogHeader>
                                  <DialogTitle>Edit Tenant</DialogTitle>
                                  <DialogDescription>Update tenant information</DialogDescription>
                                </DialogHeader>
                                <TenantForm 
                                  tenant={editingTenant} 
                                  onSubmit={handleUpdate} 
                                  isPending={updateMutation.isPending}
                                />
                              </DialogContent>
                            </Dialog>
                            <Button 
                              variant="destructive" 
                              size="sm"
                              onClick={() => handleDelete(tenant.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
