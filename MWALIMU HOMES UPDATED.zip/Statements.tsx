import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download, FileText } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { generatePDFFromHTML } from "@/lib/pdfGenerator";
import { generateTenantStatementHTML, generatePropertyStatementHTML } from "@shared/statements";

export default function Statements() {
  const [statementType, setStatementType] = useState<"tenant" | "property">("tenant");
  const [selectedProperty, setSelectedProperty] = useState<string>("");
  const [selectedTenant, setSelectedTenant] = useState<string>("");
  const [selectedMonth, setSelectedMonth] = useState<string>("");
  const [selectedYear, setSelectedYear] = useState<string>("");
  const [previewHTML, setPreviewHTML] = useState<string>("");
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  const { data: properties } = trpc.properties.list.useQuery();
  const { data: tenants } = trpc.tenants.list.useQuery();
  const { data: tenantStatement } = trpc.statements.generateTenantStatement.useQuery(
    {
      propertyId: parseInt(selectedProperty),
      tenantId: parseInt(selectedTenant),
      month: parseInt(selectedMonth),
      year: parseInt(selectedYear),
    },
    {
      enabled: statementType === "tenant" && !!selectedProperty && !!selectedTenant && !!selectedMonth && !!selectedYear,
    }
  );

  const { data: propertyStatement } = trpc.statements.generatePropertyStatement.useQuery(
    {
      propertyId: parseInt(selectedProperty),
      month: parseInt(selectedMonth),
      year: parseInt(selectedYear),
    },
    {
      enabled: statementType === "property" && !!selectedProperty && !!selectedMonth && !!selectedYear,
    }
  );

  const filteredTenants = selectedProperty
    ? tenants?.filter(t => t.propertyId === parseInt(selectedProperty))
    : tenants;

  const handleGenerateTenantStatement = () => {
    if (!tenantStatement) {
      toast.error("Unable to generate statement");
      return;
    }

    const html = generateTenantStatementHTML(tenantStatement);
    setPreviewHTML(html);
    setIsPreviewOpen(true);
  };

  const handleGeneratePropertyStatement = () => {
    if (!propertyStatement) {
      toast.error("Unable to generate statement");
      return;
    }

    const html = generatePropertyStatementHTML(propertyStatement);
    setPreviewHTML(html);
    setIsPreviewOpen(true);
  };

  const handleDownloadPDF = async () => {
    try {
      const fileName = statementType === "tenant" 
        ? `tenant-statement-${selectedMonth}-${selectedYear}.pdf`
        : `property-statement-${selectedMonth}-${selectedYear}.pdf`;
      
      await generatePDFFromHTML(previewHTML, fileName);
      toast.success("PDF downloaded successfully");
    } catch (error) {
      toast.error("Failed to download PDF");
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Statements</h1>
          <p className="text-sm text-muted-foreground mt-1">Generate payment statements for tenants or properties</p>
        </div>

        {/* Statement Type Selection */}
        <Card>
          <CardHeader>
            <CardTitle>Select Statement Type</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <Button
                onClick={() => {
                  setStatementType("tenant");
                  setSelectedTenant("");
                }}
                variant={statementType === "tenant" ? "default" : "outline"}
              >
                Tenant Statement
              </Button>
              <Button
                onClick={() => {
                  setStatementType("property");
                  setSelectedTenant("");
                }}
                variant={statementType === "property" ? "default" : "outline"}
              >
                Property Statement
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Tenant Statement Form */}
        {statementType === "tenant" && (
          <Card>
            <CardHeader>
              <CardTitle>Tenant Statement</CardTitle>
              <CardDescription>Generate a payment statement for a specific tenant</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="property">Property</Label>
                  <Select value={selectedProperty} onValueChange={setSelectedProperty}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select property..." />
                    </SelectTrigger>
                    <SelectContent>
                      {properties?.map(prop => (
                        <SelectItem key={prop.id} value={prop.id.toString()}>
                          {prop.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tenant">Tenant</Label>
                  <Select value={selectedTenant} onValueChange={setSelectedTenant}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select tenant..." />
                    </SelectTrigger>
                    <SelectContent>
                      {filteredTenants?.map(tenant => (
                        <SelectItem key={tenant.id} value={tenant.id.toString()}>
                          {tenant.firstName} {tenant.lastName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="month">Month</Label>
                  <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select month..." />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: 12 }, (_, i) => i + 1).map(month => (
                        <SelectItem key={month} value={month.toString()}>
                          {new Date(2024, month - 1).toLocaleString('default', { month: 'long' })}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="year">Year</Label>
                  <Select value={selectedYear} onValueChange={setSelectedYear}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select year..." />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i).map(year => (
                        <SelectItem key={year} value={year.toString()}>
                          {year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
                <DialogTrigger asChild>
                  <Button 
                    onClick={handleGenerateTenantStatement}
                    disabled={!selectedProperty || !selectedTenant || !selectedMonth || !selectedYear}
                    className="w-full"
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Generate Statement
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Statement Preview</DialogTitle>
                  </DialogHeader>
                  
                  {previewHTML && (
                    <div className="space-y-4">
                      <div 
                        className="border rounded-lg p-4 bg-white"
                        dangerouslySetInnerHTML={{ __html: previewHTML }}
                      />
                      
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setIsPreviewOpen(false)}>
                          Close
                        </Button>
                        <Button onClick={handleDownloadPDF}>
                          <Download className="w-4 h-4 mr-2" />
                          Download PDF
                        </Button>
                      </DialogFooter>
                    </div>
                  )}
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        )}

        {/* Property Statement Form */}
        {statementType === "property" && (
          <Card>
            <CardHeader>
              <CardTitle>Property Statement</CardTitle>
              <CardDescription>Generate a payment statement for all tenants in a property</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="property">Property</Label>
                  <Select value={selectedProperty} onValueChange={setSelectedProperty}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select property..." />
                    </SelectTrigger>
                    <SelectContent>
                      {properties?.map(prop => (
                        <SelectItem key={prop.id} value={prop.id.toString()}>
                          {prop.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="month">Month</Label>
                  <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select month..." />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: 12 }, (_, i) => i + 1).map(month => (
                        <SelectItem key={month} value={month.toString()}>
                          {new Date(2024, month - 1).toLocaleString('default', { month: 'long' })}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="year">Year</Label>
                  <Select value={selectedYear} onValueChange={setSelectedYear}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select year..." />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i).map(year => (
                        <SelectItem key={year} value={year.toString()}>
                          {year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
                <DialogTrigger asChild>
                  <Button 
                    onClick={handleGeneratePropertyStatement}
                    disabled={!selectedProperty || !selectedMonth || !selectedYear}
                    className="w-full"
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Generate Statement
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Statement Preview</DialogTitle>
                  </DialogHeader>
                  
                  {previewHTML && (
                    <div className="space-y-4">
                      <div 
                        className="border rounded-lg p-4 bg-white"
                        dangerouslySetInnerHTML={{ __html: previewHTML }}
                      />
                      
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setIsPreviewOpen(false)}>
                          Close
                        </Button>
                        <Button onClick={handleDownloadPDF}>
                          <Download className="w-4 h-4 mr-2" />
                          Download PDF
                        </Button>
                      </DialogFooter>
                    </div>
                  )}
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
