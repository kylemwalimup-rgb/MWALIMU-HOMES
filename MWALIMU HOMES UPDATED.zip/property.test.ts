  it("should list units by property ID", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const properties = await caller.properties.list();
    if (properties.length > 0) {
      const units = await caller.units.getByPropertyId({ propertyId: properties[0].id });
      expect(Array.isArray(units)).toBe(true);
    }
  });
});

describe("Tenant Management", () => {
  it("should create a tenant successfully", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.tenants.create({
      firstName: "John",
      lastName: "Doe",
      email: "john.doe@test.com",
      primaryPhone: "+254712345678",
      secondaryPhone: "+254712345679",
      nationalId: "ID123456",
    });

    expect(result).toBeDefined();
  });

  it("should list all tenants", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const tenants = await caller.tenants.list();
    expect(Array.isArray(tenants)).toBe(true);
    if (tenants.length > 0) {
      const tenant = tenants[0];
      expect(tenant).toHaveProperty("firstName");
      expect(tenant).toHaveProperty("primaryPhone");
      expect(tenant).toHaveProperty("nationalId");
    }
  });
});

describe("Dashboard Statistics", () => {
  it("should return dashboard statistics", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const stats = await caller.dashboard.stats();

    expect(stats).toBeDefined();
    expect(typeof stats.totalUnits).toBe("number");
    expect(typeof stats.occupiedUnits).toBe("number");
    expect(typeof stats.vacantUnits).toBe("number");
    expect(typeof stats.occupancyRate).toBe("number");
    expect(typeof stats.totalArrears).toBe("number");
  });

  it("should calculate occupancy rate correctly", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const stats = await caller.dashboard.stats();

    if (stats.totalUnits > 0) {
      const expectedRate = (stats.occupiedUnits / stats.totalUnits) * 100;
      expect(stats.occupancyRate).toBeCloseTo(expectedRate, 2);
    } else {
      expect(stats.occupancyRate).toBe(0);
    }
  });
});
