CREATE TABLE `leaseAgreements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`leaseId` int NOT NULL,
	`templateId` int NOT NULL,
	`generatedContent` text NOT NULL,
	`signedDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `leaseAgreements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `leaseTemplates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`content` text NOT NULL,
	`isDefault` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `leaseTemplates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `tenants` ADD `primaryPhone` varchar(20) NOT NULL;--> statement-breakpoint
ALTER TABLE `tenants` ADD `secondaryPhone` varchar(20) NOT NULL;--> statement-breakpoint
ALTER TABLE `tenants` ADD `nationalId` varchar(50) NOT NULL;--> statement-breakpoint
ALTER TABLE `tenants` DROP COLUMN `phone`;--> statement-breakpoint
ALTER TABLE `tenants` DROP COLUMN `idNumber`;--> statement-breakpoint
ALTER TABLE `tenants` DROP COLUMN `emergencyContact`;--> statement-breakpoint
ALTER TABLE `tenants` DROP COLUMN `emergencyContactName`;