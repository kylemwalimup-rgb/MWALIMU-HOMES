/**
 * M-Pesa message parser utility
 * Extracts payment information from M-Pesa confirmation messages
 */

export interface ParsedMpesaPayment {
  amount: number;
  payerName: string;
  phoneNumber: string;
  mpesaReference: string;
  accountReference: string;
  datePaid: Date;
  timePaid: string;
  rawMessage: string;
}

/**
 * Parse a single M-Pesa confirmation message
 * Example: (Confirmed KES. 2,500.00 to BENJAMINMWALIMUKYONGO A/C Ref.Number 577499 Via MPESA Ref TLO8G1XDCL by SHEDRACK KIOKO MUTUA Phone 254748908204 on 24-12-2025 at 12:55.Thank you.)
 */
export function parseMpesaMessage(message: string): ParsedMpesaPayment | null {
  try {
    // Extract amount (KES. X,XXX.XX)
    const amountMatch = message.match(/KES\.\s*([\d,]+\.\d{2})/i);
    if (!amountMatch) return null;
    const amount = parseFloat(amountMatch[1].replace(/,/g, ''));

    // Extract payer name (by NAME)
    const nameMatch = message.match(/by\s+([A-Z\s]+?)\s+Phone/i);
    const payerName = nameMatch ? nameMatch[1].trim() : '';

    // Extract phone number (Phone XXXXXXXXX)
    const phoneMatch = message.match(/Phone\s+(\d+)/);
    const phoneNumber = phoneMatch ? phoneMatch[1] : '';

    // Extract M-Pesa reference (Ref XXXXXXXXX)
    const refMatch = message.match(/Ref\s+([A-Z0-9]+)/);
    const mpesaReference = refMatch ? refMatch[1] : '';

    // Extract account reference (A/C Ref.Number XXXXXX)
    const acRefMatch = message.match(/A\/C\s+Ref\.?Number\s+(\d+)/i);
    const accountReference = acRefMatch ? acRefMatch[1] : '';

    // Extract date (on DD-MM-YYYY)
    const dateMatch = message.match(/on\s+(\d{2})-(\d{2})-(\d{4})/);
    let datePaid = new Date();
    if (dateMatch) {
      const [, day, month, year] = dateMatch;
      datePaid = new Date(`${year}-${month}-${day}`);
    }

    // Extract time (at HH:MM)
    const timeMatch = message.match(/at\s+(\d{2}:\d{2})/);
    const timePaid = timeMatch ? timeMatch[1] : '';

    return {
      amount,
      payerName,
      phoneNumber,
      mpesaReference,
      accountReference,
      datePaid,
      timePaid,
      rawMessage: message,
    };
  } catch (error) {
    console.error('Error parsing M-Pesa message:', error);
    return null;
  }
}

/**
 * Parse multiple M-Pesa messages (one per line)
 */
export function parseBulkMpesaMessages(text: string): ParsedMpesaPayment[] {
  const lines = text.split('\n').filter(line => line.trim().length > 0);
  const payments: ParsedMpesaPayment[] = [];

  for (const line of lines) {
    const parsed = parseMpesaMessage(line);
    if (parsed) {
      payments.push(parsed);
    }
  }

  return payments;
}

/**
 * Calculate match score for tenant matching
 * Returns a score from 0-100 based on name and phone similarity
 */
export function calculateMatchScore(
  tenantName: string,
  tenantPhone: string,
  payerName: string,
  payerPhone: string
): number {
  let score = 0;

  // Phone number exact match (highest priority)
  if (tenantPhone && payerPhone && tenantPhone.includes(payerPhone.slice(-9))) {
    score += 70;
  }

  // Name similarity (check if any part of payer name matches tenant name)
  const tenantNameParts = tenantName.toLowerCase().split(/\s+/);
  const payerNameParts = payerName.toLowerCase().split(/\s+/);

  for (const payerPart of payerNameParts) {
    for (const tenantPart of tenantNameParts) {
      if (tenantPart.length > 3 && payerPart.includes(tenantPart)) {
        score += 15;
        break;
      }
    }
  }

  return Math.min(score, 100);
}
