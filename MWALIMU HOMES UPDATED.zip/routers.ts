      .query(async ({ input }) => {
        return await db.getUnitById(input.id);
      }),
    
    create: protectedProcedure
      .input(z.object({
        propertyId: z.number(),
        unitNumber: z.string().min(1),
        unitType: z.enum(["bedsitter", "1BR", "2BR", "shop"]),
        baseRent: z.string(),
        serviceCharge: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createUnit({
          ...input,
          serviceCharge: input.serviceCharge || "0.00",
        });
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        unitNumber: z.string().min(1).optional(),
        unitType: z.enum(["bedsitter", "1BR", "2BR", "shop"]).optional(),
        baseRent: z.string().optional(),
        serviceCharge: z.string().optional(),
        status: z.enum(["vacant", "occupied", "maintenance"]).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateUnit(id, data);
      }),
    
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))