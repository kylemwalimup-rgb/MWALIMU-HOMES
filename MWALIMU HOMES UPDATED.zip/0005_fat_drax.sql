ALTER TABLE `tenants` MODIFY COLUMN `secondaryPhone` varchar(20);--> statement-breakpoint
ALTER TABLE `tenants` ADD `propertyId` int NOT NULL;--> statement-breakpoint
ALTER TABLE `tenants` ADD `unitId` int NOT NULL;--> statement-breakpoint
ALTER TABLE `tenants` ADD `identityCardFile` varchar(255);--> statement-breakpoint
ALTER TABLE `tenants` ADD `moveInDate` varchar(10);--> statement-breakpoint
ALTER TABLE `tenants` ADD `monthlyRent` decimal(10,2) NOT NULL;--> statement-breakpoint
ALTER TABLE `tenants` ADD `securityDeposit` decimal(10,2) NOT NULL;--> statement-breakpoint
ALTER TABLE `tenants` ADD `electricityDeposit` decimal(10,2) DEFAULT '0.00' NOT NULL;--> statement-breakpoint
ALTER TABLE `tenants` ADD `agreementFile` varchar(255);